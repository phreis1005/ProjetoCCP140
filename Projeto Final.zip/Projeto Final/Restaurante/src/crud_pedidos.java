/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author uniepgeraldo
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
public class crud_pedidos {
    private Connection conn;
    private PreparedStatement pstm;
    private PreparedStatement pstmt;
    private ResultSet rs;
    protected String ListaCadastro=""; 
    String[] lista_produtos;
    String[] lista_qtd;
    
    
    public String buscar() {
        // Abrindo a conexão com o banco​
        Conecta conexao = new Conecta();
        conn = conexao.conectar();
        System.out.println("aqui1");
        ListaCadastro = "";
        try {
            // Instanciando o objeto preparedStatement (pstmt)​
            
            pstmt = conn.prepareStatement("SELECT * FROM PROJETO ORDER BY CPF");
            // Executando o comando sql e armazenando no ResultSet
            rs = pstmt.executeQuery();
            while (rs.next()) {
               lista_produtos = (String[])rs.getArray("PRODUTOS").getArray();
               lista_qtd = (String[])rs.getArray("QUANTIDADE").getArray();
               
               String lista = ("Nome: " + rs.getString("NOME") + "\n" + "Pedido: "+rs.getString("STATUS")+"\n");
               ListaCadastro = ListaCadastro + lista;
            for(int i=0;i<lista_produtos.length;i++){
                ListaCadastro = ListaCadastro + lista_qtd[i]+" - "+lista_produtos[i]+"\n";
            
            }
            ListaCadastro = ListaCadastro + "\n";
           }
            
            
            System.out.println("Aqui");
            System.out.println(ListaCadastro);
                    
            //Retornando o ResultSet​
             return ListaCadastro;
        } catch (SQLException e) {
            conexao.desconectar();
            return null;
        }
    }
    public String buscarPorCpf(String cpf) {
        // Abrindo a conexão com o banco​
        Conecta conexao = new Conecta();
        conn = conexao.conectar();
        ListaCadastro = "";
        try {
            // Instanciando o objeto preparedStatement (pstmt)​
            pstmt = conn.prepareStatement("SELECT * FROM PROJETO WHERE CPF = ? ORDER BY CPF");
            pstmt.setString(1, cpf);
            // Executando o comando sql e armazenando no ResultSet
            rs = pstmt.executeQuery();
            while (rs.next()) {
               lista_produtos = (String[])rs.getArray("PRODUTOS").getArray();
               lista_qtd = (String[])rs.getArray("QUANTIDADE").getArray();
               
               String lista = ("Nome: " + rs.getString("NOME") + "\n" + "Pedido: "+rs.getString("STATUS")+"\n");
               ListaCadastro = ListaCadastro + lista;
            for(int i=0;i<lista_produtos.length;i++){
                ListaCadastro = ListaCadastro + lista_qtd[i]+" - "+lista_produtos[i]+"\n";
                
            }
           }
            System.out.println(ListaCadastro);
            return ListaCadastro;
        } catch (SQLException e) {
            conexao.desconectar();
            return null;
        }
}
    public String buscarPorStatus(String status) {
        // Abrindo a conexão com o banco​
        Conecta conexao = new Conecta();
        conn = conexao.conectar();
        ListaCadastro = "";
        try {
            // Instanciando o objeto preparedStatement (pstmt)​
            pstmt = conn.prepareStatement("SELECT * FROM PROJETO WHERE STATUS = ? ORDER BY CPF");
            pstmt.setString(1, status);
            // Executando o comando sql e armazenando no ResultSet
            rs = pstmt.executeQuery();
            while (rs.next()) {
               lista_produtos = (String[])rs.getArray("PRODUTOS").getArray();
               lista_qtd = (String[])rs.getArray("QUANTIDADE").getArray();
               
               String lista = ("Nome: " + rs.getString("NOME") + "\n" + "Pedido: "+rs.getString("STATUS")+"\n");
               ListaCadastro = ListaCadastro + lista;
            for(int i=0;i<lista_produtos.length;i++){
                ListaCadastro = ListaCadastro + lista_qtd[i]+" - "+lista_produtos[i]+"\n";
                
            }
            ListaCadastro = ListaCadastro + "\n";
           }
            System.out.println(ListaCadastro);
            return ListaCadastro;
        } catch (SQLException e) {
            conexao.desconectar();
            return null;
        }
    }
        public void pedido_pronto(String cpf){
        Conecta conect = new Conecta();
        this.conn = conect.conectar();
        if (conn==null)
            System.out.println("Erro na conexão");
        else
            System.out.println("Conectado com a base de dados");
        
        try {
            pstm = conn.prepareStatement("UPDATE PROJETO SET STATUS = ? WHERE CPF = ?");
            pstm.setString(1, "PRONTO");
            pstm.setString(2, cpf);
            pstm.execute();
            System.out.println("Inserido com sucesso");
            conect.desconectar();
        } catch (SQLException ex) {
            System.out.println("Falha ao inserir no DB: " + ex.getMessage());
        }
    }
    public String extrato(String cpf) {
        String lista_extrato = "";
        Conecta conexao = new Conecta();
        conn = conexao.conectar();
        ListaCadastro = "";
        try {
            // Instanciando o objeto preparedStatement (pstmt)​
            pstmt = conn.prepareStatement("SELECT * FROM PROJETO WHERE CPF = ? ORDER BY CPF");
            pstmt.setString(1, cpf);
            // Executando o comando sql e armazenando no ResultSet
            rs = pstmt.executeQuery();
            double total_price=0;
            while (rs.next()) {
               lista_produtos = (String[])rs.getArray("PRODUTOS").getArray();
               lista_qtd = (String[])rs.getArray("QUANTIDADE").getArray();
               ListaCadastro = ("Nome: " + rs.getString("NOME") + "\n" + "Pedido:"+"\n");
               for (int i=0;i<lista_qtd.length;i++){
                   double price=0;
                   if ("X-Salada".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*10;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("X-Burguer".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*10;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("Cachorro quente".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*7.5;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("Misto quente".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*8;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("Salada de frutas".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*5.5;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("Refrigerante".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*4.5;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("Suco natural".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*6.25;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   total_price = total_price+price;
                   System.out.println(lista_extrato);
               }
            }
               if(total_price !=0)
               ListaCadastro = ListaCadastro + lista_extrato+ "Valor total: "+total_price;
               System.out.println(ListaCadastro);
               return ListaCadastro;
        } catch (SQLException e) {
            conexao.desconectar();
            return null;
        }
        
        
        
    }
    }
    
    

