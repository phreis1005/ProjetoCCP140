/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author uniepgeraldo
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
public class crud_cadastros {
    private Connection conn;
    private PreparedStatement pstm;
    private PreparedStatement pstmt;
    private ResultSet rs;
    protected String ListaCadastro=""; 
    
    public void remover(String cpf){
        Conecta conexao = new Conecta();
        conn = conexao.conectar();
        try {
            pstm = conn.prepareStatement("DELETE FROM PROJETO WHERE CPF = ?");
            pstm.setString(1,cpf);
            pstm.execute();
            System.out.println("Removido com sucesso");
            conexao.desconectar();
        } catch (SQLException ex) {
            System.out.println("Falha ao inserir no DB: " + ex.getMessage());
        }}
    public String buscar() {
        // Abrindo a conexão com o banco​
        Conecta conexao = new Conecta();
        conn = conexao.conectar();
        ListaCadastro = "";
        try {
            // Instanciando o objeto preparedStatement (pstmt)​
            pstmt = conn.prepareStatement("SELECT * FROM PROJETO ORDER BY CPF");
            // Executando o comando sql e armazenando no ResultSet
            rs = pstmt.executeQuery();
            while (rs.next()) {
               String lista = ("Nome: " + rs.getString("NOME") + " - " + "CPF: "
                       + rs.getString("CPF")+"\n");
               ListaCadastro = ListaCadastro + lista;
           }
            System.out.println(ListaCadastro);
                    
            //Retornando o ResultSet​
             return ListaCadastro;
        } catch (SQLException e) {
            conexao.desconectar();
            return null;
        }
    }
    
    
}
