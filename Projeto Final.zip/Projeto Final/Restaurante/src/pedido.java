/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author uniepgeraldo
 */
public class pedido {
    private String produtos[];
    private int quantidade[];

    public pedido(String[] produtos, int[] quantidade) {
        this.produtos = produtos;
        this.quantidade = quantidade;
    }

    public String[] getProdutos() {
        return produtos;
    }

    public int[] getQuantidade() {
        return quantidade;
    }

    public void setProdutos(String[] produtos) {
        this.produtos = produtos;
    }

    public void setQuantidade(int[] quantidade) {
        this.quantidade = quantidade;
    }

    

    

    

    @Override
    public String toString() {
        return "pedido{" + "produto=" + produtos + ", quantidade=" + quantidade + '}';
    }
    
    
}
