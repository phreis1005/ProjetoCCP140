
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Pedro Henrique
 */
import java.sql.SQLException;

public class Edit extends Pedidos {
    private static int pedido1;
    private static int pedido2;
    private static int pedido3;
    private static int pedido4;
    private static int pedido5;
    private static int pedido6;
    private static int pedido7;
    
    
    public void edit(){
        
        this.conn = conect.conectar();
        
        String[] lista_produtos;
        String[] lista_qtd;
        int[] lista_quant = null;
        
        
        if (conn==null)
            System.out.println("Erro na conexão");
        else
            System.out.println("Conectado com a base de dados");
        
        try {
            pstm = conn.prepareStatement("SELECT * FROM PROJETO WHERE CPF = ?");
            pstm.setString(1, cpf_atual);
            // Executando o comando sql e armazenando no ResultSet
            rs = pstm.executeQuery();
            while (rs.next()) {
               lista_produtos = (String[])rs.getArray("PRODUTOS").getArray();
               lista_qtd = (String[])rs.getArray("QUANTIDADE").getArray();
               
               for (int i=0;i<lista_qtd.length;i++){
                       double price=0;
                       if ("X-Salada".equals(lista_produtos[i])){
                           pedido1 = Integer.parseInt(lista_qtd[i]);
                          }
                       else if ("X-Burguer".equals(lista_produtos[i])){
                           pedido2 = Integer.parseInt(lista_qtd[i]);
                          }
                       else if ("Cachorro quente".equals(lista_produtos[i])){
                           pedido3 = Integer.parseInt(lista_qtd[i]);
                          }
                       else if ("Misto quente".equals(lista_produtos[i])){
                           pedido4 = Integer.parseInt(lista_qtd[i]);
                          }
                       else if ("Salada de frutas".equals(lista_produtos[i])){
                           pedido5 = Integer.parseInt(lista_qtd[i]);
                          }
                       else if ("Refrigerante".equals(lista_produtos[i])){
                           pedido6 = Integer.parseInt(lista_qtd[i]);
                          }
                       else if ("Suco natural".equals(lista_produtos[i])){
                           pedido7 = Integer.parseInt(lista_qtd[i]);
                          }
                   }
            }

            conect.desconectar(); 
        } catch (SQLException ex) {
            System.out.println("Falha ao inserir no DB: " + ex.getMessage());
        }
    }
    
    
    

    public static void setPedido1(int pedido1) {
        Edit.pedido1 = pedido1;
    }

    public static void setPedido2(int pedido2) {
        Edit.pedido2 = pedido2;
    }

    public static void setPedido3(int pedido3) {
        Edit.pedido3 = pedido3;
    }

    public static void setPedido4(int pedido4) {
        Edit.pedido4 = pedido4;
    }

    public static void setPedido5(int pedido5) {
        Edit.pedido5 = pedido5;
    }

    public static void setPedido6(int pedido6) {
        Edit.pedido6 = pedido6;
    }

    public static void setPedido7(int pedido7) {
        Edit.pedido7 = pedido7;
    }

    public static int getPedido1() {
        return pedido1;
    }

    public static int getPedido2() {
        return pedido2;
    }

    public static int getPedido3() {
        return pedido3;
    }

    public static int getPedido4() {
        return pedido4;
    }

    public static int getPedido5() {
        return pedido5;
    }

    public static int getPedido6() {
        return pedido6;
    }

    public static int getPedido7() {
        return pedido7;
    }


    
}
