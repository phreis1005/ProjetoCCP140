/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author pedro
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Set;
import java.sql.ResultSet;

public class Pedidos extends Conexão {
    //private Connection conn;
    public PreparedStatement pstm;
    public static String cpf_atual;
    public ResultSet rs;
    
    Conexão conect = new Conexão();

    public String getCpf_atual() {
        return cpf_atual;
    }

    public void setCpf_atual(String cpf_atual) {
        this.cpf_atual = cpf_atual;
    }
    
    public void remove(){
        this.conn = conect.conectar();
        
        if (conn==null)
            System.out.println("Erro na conexão");
        else
            System.out.println("Conectado com a base de dados");
        
        try {
            pstm = conn.prepareStatement("UPDATE PROJETO SET STATUS = null, QUANTIDADE = null, PRODUTOS = null  WHERE CPF = ?");
            pstm.setString(1, cpf_atual);
            pstm.execute();
            System.out.println("Removido com sucesso");
            conect.desconectar();
        } catch (SQLException ex) {
            System.out.println("Falha ao inserir no DB: " + ex.getMessage());
        }
    }
    
    public void salvar(ArrayList<Integer> quant, ArrayList<String> pedidos) throws SQLException{
        this.conn = conect.conectar();

        if (conn==null)
            System.out.println("Erro na conexão");
        else
            System.out.println("Conectado com a base de dados");
        
        String[] quantArray = new String[quant.size()];
        String[] pedidosArray = new String[pedidos.size()];
        int index = 0;
        for(int value : quant){
            quantArray[index] = Integer.toString(value);
            index++;
        }
        index = 0;
        for(String value : pedidos){
            pedidosArray[index] = (String) value;
            index++;
        }
        final java.sql.Array quantArray2 = conn.createArrayOf("VARCHAR",quantArray );
        final java.sql.Array pedidosArray2 = conn.createArrayOf("VARCHAR",pedidosArray );
        
        
        try {
            pstm = conn.prepareStatement("UPDATE PROJETO SET STATUS = ?, QUANTIDADE = ?, PRODUTOS = ?  WHERE CPF = ?");
            pstm.setString(1,"EM PROGRESSO");
            pstm.setArray(2,quantArray2);
            pstm.setArray(3,pedidosArray2);
            pstm.setString(4,cpf_atual);
            pstm.execute();
            System.out.println("Pedido cadastrado com sucesso");
            conect.desconectar();
        } catch (SQLException ex) {
            System.out.println("Falha ao inserir no DB: " + ex.getMessage());
        }
    }  
    
    
    
    public String extrato() {
        this.conn = conect.conectar();
        
        if (conn==null)
            System.out.println("Erro na conexão");
        else
            System.out.println("Conectado com a base de dados");
        
        String[] lista_produtos;
        String[] lista_qtd;
        String ListaCadastro = "";
        String lista_extrato = "";
        try {
            // Instanciando o objeto preparedStatement (pstmt)​
            pstm = conn.prepareStatement("SELECT * FROM PROJETO WHERE CPF = ?");
            pstm.setString(1, cpf_atual);
            // Executando o comando sql e armazenando no ResultSet
            rs = pstm.executeQuery();
            double total_price=0;
            while (rs.next()) {
               lista_produtos = (String[])rs.getArray("PRODUTOS").getArray();
               lista_qtd = (String[])rs.getArray("QUANTIDADE").getArray();
               ListaCadastro = ("Nome: " + rs.getString("NOME") + "\n" + "Pedido:"+"\n");
               for (int i=0;i<lista_qtd.length;i++){
                   double price=0;
                   if ("X-Salada".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*10;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("X-Burguer".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*10;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("Cachorro quente".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*7.5;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("Misto quente".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*8;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("Salada de frutas".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*5.5;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("Refrigerante".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*4.5;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   else if ("Suco natural".equals(lista_produtos[i])){
                       price = Integer.parseInt(lista_qtd[i])*6.25;
                      lista_extrato = lista_extrato + lista_qtd[i]+" - "+lista_produtos[i]+" - Valor: $"+price+"\n";}
                   total_price = total_price+price;
                   System.out.println(lista_extrato);
                  
               }
            }
            ListaCadastro = ListaCadastro + lista_extrato+ "Valor total: $"+total_price;
            System.out.println(ListaCadastro);
            return ListaCadastro;
            } 
        catch (SQLException e) {
            System.out.println("Falha ao inserir no DB");
            return "ERRO NO BANCO DE DADOS";
        }
        catch (NullPointerException e1){
            System.out.println("Nenhum pedido cadastrado");
            return "ERRO, NENHUM PEDIDO CADASTRADO";
        }
          
        
        
        
        
    }
}

