


import java.sql.SQLException;  
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class VerificaLogin {
    private final Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs; 

    public VerificaLogin() {
        Conexão Conexão = new Conexão();
        conn = Conexão.conectar();
    }
   
    public boolean verificaLogin(Cliente usuario){
        
        String sql = "select * from projeto where cpf = ? and senha = ?";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, usuario.getCpf());
            pstmt.setString(2, usuario.getSenha());
            // Executando o comando sql e armazenando no ResultSet
            rs = pstmt.executeQuery();
            //Retornando o ResultSet​
            while(rs.next()){
                return true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return false;
    }
}

