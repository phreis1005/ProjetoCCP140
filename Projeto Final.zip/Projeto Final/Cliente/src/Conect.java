/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author uniepedreis
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author uniepedreis
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public abstract class Conect {
    
    public abstract Connection conectar();    
    public abstract void desconectar();
     
    
    
}
