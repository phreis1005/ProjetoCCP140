/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author pedro
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Cadastro {
    private Connection conn;
    private PreparedStatement pstm;

    public void inserir(Cliente cliente){
        Conexão conect = new Conexão();
        this.conn = conect.conectar();
        if (conn==null)
            System.out.println("Erro na conexão");
        else
            System.out.println("Conectado com a base de dados");
        
        try {
            pstm = conn.prepareStatement("INSERT INTO PROJETO (NOME,CPF,SENHA) VALUES (?, ?, ?)");
            pstm.setString(1, cliente.getNome());
            pstm.setString(2, cliente.getCpf());
            pstm.setString(3, cliente.getSenha());
            pstm.execute();
            System.out.println("Inserido com sucesso");
            conect.desconectar();
        } catch (SQLException ex) {
            System.out.println("Falha ao inserir no DB: " + ex.getMessage());
        }
    }
}
